
 // $(function($) {
    
 //    $(".phone_main_c").mask("999-99-99-99");
 //    $(".phone_alternate_c").mask("999-99-99-99");
 //  });

function set_date_end_for_CDD(){
 
 
     var type_de_cont =  $(".typeofcontract_c").val();

     if(type_de_cont == "1")
     {
       $(".edn_date_contract_cdd").val("");
      
     }
     
   }

 $(function($) {

       

    var today = new Date();
    $('.dob').datepicker({
      changeMonth: true,
        changeYear: true,
        dateFormat: 'dd-mm-yy',    
        maxDate: today.getDate(),
        changeMonth: true,
        numberOfMonths: 1
    });

    $('.expiration_date').datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd-mm-yy',    
        yearRange: "1980:2050",
        changeMonth: true,
        numberOfMonths: 1

    });

    $('.edn_date_contract_cdd').datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd-mm-yy',    
        yearRange: "1980:2050",
        changeMonth: true,
        numberOfMonths: 1,
        onSelect: function(selected,evnt) {
         set_date_end_for_CDD();
        },

    });
   

    $('.employment_date').datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd-mm-yy',    
        maxDate: today.getDate(),
        changeMonth: true,
        numberOfMonths: 1

    });
  

    $('.current_emp').datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd-mm-yy',    
        changeMonth: true,
        numberOfMonths: 1

    });
    //$("#current_emp").mask("99-99-9999");
    $('.opening_date').datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd-mm-yy',    
        changeMonth: true,
        numberOfMonths: 1
    });


     $('.stu_dob').datepicker({
        changeMonth: true,
        changeYear: true,
        dateFormat: 'dd-mm-yy',    
        maxDate: today.getDate(),
        changeMonth: true,
        numberOfMonths: 1

    });

  });


    function format(inputDate) {
      var date = new Date(inputDate);
      if (!isNaN(date.getTime())) {
          // Months use 0 index.
          return date.getMonth() + 1 + '-' + date.getDate() + '-' + date.getFullYear();
      }
    }

    function getAge(DOB) {
      var today = new Date();
      var birthDate = new Date(DOB);
      var age = today.getFullYear() - birthDate.getFullYear();
      var m = today.getMonth() - birthDate.getMonth();
      if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
          age = age - 1;
      }

      return age;
    }

   $(".dob").on("click change",function(){

        var date_value  =  $(this).val();
        var format_date = format(date_value);

        //alert(format_date);

        if(getAge(format_date) <= 18)
        {
          alert("Customer's Age must be above 18 yrs");
          $(this).val('');
        }
        
    });