
// Start Phone no. in split tab

//  var inputphone1 = document.querySelector("#main_phone"),
//   errorMsg1 = document.querySelector("#main_phoneerror-msg"),
//   validMsg1 = document.querySelector("#main_phonevalid-msg");

// // here, the index maps to the error code returned from getValidationError - see readme
// var errorMap1 = ["Invalid number", "Invalid country code", "Too short", "Too long", "Invalid number"];

// // initialise plugin
// var iti1 = window.intlTelInput(inputphone1, {
//   hiddenInput: "full_mainph_number",
//   utilsScript: base_url+"assets/intl-tel-input-master/build/js/utils.js?1585994360633"
// });

// var reset = function() {
//   inputphone1.classList.remove("error");
//   errorMsg1.innerHTML = "";
//   errorMsg1.classList.add("hide");
//   validMsg1.classList.add("hide");
// };

// // on blur: validate
// inputphone1.addEventListener('blur', function() {
//   reset();
//   if (inputphone1.value.trim()) {
//     if (iti1.isValidNumber()) {
//       validMsg1.classList.remove("hide");
//     } else {
//       inputphone1.classList.add("error");
//       var errorCode1 = iti1.getValidationError();
//       errorMsg1.innerHTML = errorMap1[errorCode1];
//       errorMsg1.classList.remove("hide");
//     }
//   }
// });

// // on keyup / change flag: reset
// inputphone1.addEventListener('change', reset);
// inputphone1.addEventListener('keyup', reset);


// // End Phone no. in split tab


// // Start Alternate Phone no. in split tab

//  var inputphone_alt1 = document.querySelector("#alternative_phone"),
//   errorMsg_alt1 = document.querySelector("#alternative_phoneerror-msg"),
//   validMsg_alt1 = document.querySelector("#alternative_phonevalid-msg");

// // here, the index maps to the error code returned from getValidationError - see readme
// var errorMap_alt1 = ["Invalid number", "Invalid country code", "Too short", "Too long", "Invalid number"];

// // initialise plugin
// var iti_alt1 = window.intlTelInput(inputphone_alt1, {
//   hiddenInput: "full_alternateph_number",
//   utilsScript: base_url+"assets/intl-tel-input-master/build/js/utils.js?1585994360633"
// });

// var reset = function() {
//   inputphone_alt1.classList.remove("error");
//   errorMsg_alt1.innerHTML = "";
//   errorMsg_alt1.classList.add("hide");
//   validMsg_alt1.classList.add("hide");
// };

// // on blur: validate
// inputphone_alt1.addEventListener('blur', function() {
//   reset();
//   if (inputphone_alt1.value.trim()) {
//     if (iti_alt1.isValidNumber()) {
//       validMsg_alt1.classList.remove("hide");
//     } else {
//       inputphone_alt1.classList.add("error");
//       var errorCode_alt1 = iti1.getValidationError();
//       errorMsg_alt1.innerHTML = errorMap_alt1[errorCode_alt1];
//       errorMsg_alt1.classList.remove("hide");
//     }
//   }
// });

// // on keyup / change flag: reset
// inputphone_alt1.addEventListener('change', reset);
// inputphone_alt1.addEventListener('keyup', reset);

// End Alternate Phone no. in split tab



 // Start Phone no. in details tab

 var inputphone2 = document.querySelector("#phone2"),
  errorMsg = document.querySelector("#phone2error-msg"),
  validMsg = document.querySelector("#phone2valid-msg");

// here, the index maps to the error code returned from getValidationError - see readme
var errorMap = ["Invalid number", "Invalid country code", "Too short", "Too long", "Invalid number"];

// initialise plugin
var iti = window.intlTelInput(inputphone2, {
  hiddenInput: "full_main_number",
  initialCountry: "cm",
  utilsScript: base_url+"assets/intl-tel-input-master/build/js/utils.js?1585994360633"
});

var reset = function() {
  inputphone2.classList.remove("error");
  errorMsg.innerHTML = "";
  errorMsg.classList.add("hide");
  validMsg.classList.add("hide");
};

// on blur: validate
inputphone2.addEventListener('blur', function() {
  reset();
  if (inputphone2.value.trim()) {
    if (iti.isValidNumber()) {
      validMsg.classList.remove("hide");
    } else {
      inputphone2.classList.add("error");
      var errorCode = iti.getValidationError();
      errorMsg.innerHTML = errorMap[errorCode];
      errorMsg.classList.remove("hide");
    }
  }
});

// on keyup / change flag: reset
inputphone2.addEventListener('change', reset);
inputphone2.addEventListener('keyup', reset);


// End Phone no. in details tab



// Start Alternate phone no. in details tab

var inputphone_alt2 = document.querySelector("#phone_alt2"),
  errorMsg_alt2 = document.querySelector("#phone_alt2error-msg"),
  validMsg_alt2 = document.querySelector("#phone_alt2valid-msg");

// here, the index maps to the error code returned from getValidationError - see readme
var errorMap_alt2 = ["Invalid number", "Invalid country code", "Too short", "Too long", "Invalid number"];

// initialise plugin
var iti_alt2 = window.intlTelInput(inputphone_alt2, {
  hiddenInput: "full_alternate_number",
  initialCountry: "cm",
  utilsScript: base_url+"assets/intl-tel-input-master/build/js/utils.js?1585994360633"
});

var reset = function() {
  inputphone_alt2.classList.remove("error");
  errorMsg_alt2.innerHTML = "";
  errorMsg_alt2.classList.add("hide");
  validMsg_alt2.classList.add("hide");
};

// on blur: validate
inputphone_alt2.addEventListener('blur', function() {
  reset();
  if (inputphone_alt2.value.trim()) {
    if (iti_alt2.isValidNumber()) {
      validMsg_alt2.classList.remove("hide");
    } else {
      inputphone_alt2.classList.add("error");
      var errorCode_alt2 = iti_alt2.getValidationError();
      errorMsg_alt2.innerHTML = errorMap_alt2[errorCode_alt2];
      errorMsg_alt2.classList.remove("hide");
    }
  }
});

// on keyup / change flag: reset
inputphone_alt2.addEventListener('change', reset);
inputphone_alt2.addEventListener('keyup', reset);



